# LeetCode 150 Interview Questions - Python Solutions

This repository contains 150+ curated LeetCode problems commonly asked in interviews.  
Problems are organized pattern-wise to help understand common approaches.

## Patterns Covered
- Arrays
- Strings
- Linked Lists
- Stacks & Queues
- Trees
- Graphs
- Dynamic Programming
- Backtracking

Each folder contains:
1. Problem solutions in Python
2. Problem link
3. Approach summary & Time/Space complexity
