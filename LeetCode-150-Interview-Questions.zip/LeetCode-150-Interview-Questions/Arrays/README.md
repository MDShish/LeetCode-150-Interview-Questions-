# Arrays

## Pattern Summary
- Common operations: Sliding window, Prefix sum, Two pointers
- Often used for subarray/subsequence problems

## Problems
1. Two Sum
   - Link: https://leetcode.com/problems/two-sum/
   - Approach: Hashmap for O(n) solution
2. Maximum Subarray
   - Link: https://leetcode.com/problems/maximum-subarray/
   - Approach: Kadane’s Algorithm for O(n) solution
