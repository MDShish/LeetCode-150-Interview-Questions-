# Stacks & Queues

## Pattern Summary
- LIFO/FIFO operations, Monotonic Stack
