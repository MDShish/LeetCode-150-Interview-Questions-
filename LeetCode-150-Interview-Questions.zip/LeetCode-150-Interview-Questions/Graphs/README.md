# Graphs

## Pattern Summary
- BFS, DFS, Shortest Path, Connected Components
