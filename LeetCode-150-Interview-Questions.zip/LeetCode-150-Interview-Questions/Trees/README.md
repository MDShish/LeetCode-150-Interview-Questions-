# Trees

## Pattern Summary
- Traversals, LCA, Depth/Breadth First Search
