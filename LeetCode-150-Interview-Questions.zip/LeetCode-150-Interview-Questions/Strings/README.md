# Strings

## Pattern Summary
- Common string manipulation and substring problems
- Sliding window, Hashing techniques
