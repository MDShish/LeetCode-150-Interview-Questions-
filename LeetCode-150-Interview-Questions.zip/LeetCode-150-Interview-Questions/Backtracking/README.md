# Backtracking

## Pattern Summary
- N-Queens, Permutations, Combinations
